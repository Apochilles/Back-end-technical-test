//future tests to implement

// Title: Post data successfully to createFilm enpoint with the correct fields

// Description: A entry should be added to the table 

// Precondition: the user must already be registered with an email address and password.

// Assumption: a supported browser is being used.

// Test Steps:

//     Navigate to gmail.com
//     In the ’email’ field, enter the email address of the registered user.
//     Click the ‘Next’ button.
//     Enter the password of the registered user
//     Click ‘Sign In’

// Expected Result: A page displaying the gmail user’s inbox should load, showing any new message at the top of the page.
