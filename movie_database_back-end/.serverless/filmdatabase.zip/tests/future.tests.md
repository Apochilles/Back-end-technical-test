# future tests to implement

## Title: Post data successfully to createFilm enpoint with the correct fields

### Description: A entry should be added to the table

### Precondition: the user should be authenticated through AWS credentials

### Assumption: a supported browser is being used.

## Test Steps:

### Navigate to the Postman application

### Ensure they have an Access and SecretKey the authorization tab

### Selet POST and put the endpoint url into the search box.

### Select Body and write out a JSON object with 

### Enter the password of the registered user

### Click ‘Sign In’

### Expected Result: A page displaying the gmail user’s inbox should load, showing any new message at the top of the page.
