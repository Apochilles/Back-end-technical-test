

https://9k4undpyqk.execute-api.ap-southeast-2.amazonaws.com/dev/films: This returns the movies that are available

https://9k4undpyqk.execute-api.ap-southeast-2.amazonaws.com/dev/films/{number}: This returns the details of a single movie

https://9k4undpyqk.execute-api.ap-southeast-2.amazonaws.com/dev/film: Post a movie to the endpoint
